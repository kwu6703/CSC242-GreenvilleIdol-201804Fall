﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Windows.Forms;

/**************************************
 * Names:               Jonathan Cooper, 
 *                      Minh Nhat Dang, 
 *                      Colin Helton, 
 *                      Ian Stebbins, 
 *                      Kaixin Wu
 * Date Started:        11/29/2018
 * Date Due:            12/14/2018
 * Description:         Greenville Idol - 
 *                      
 * This is an application for Greenville Idol taken from several case studies found in:
 * Farrell, J. (2018). Microsoft Visual C# 2017: An introduction to object-oriented programming (7th ed.). Boston, MA: Cengage Learning.
 * 
 * This is a student final project for CSC242 Object-Oriented Programming.  Students serve as the development team under the direction of an instructor.
 * 
 * Resources:  Microsoft Azure DevOps
 *             https://dev.azure.com/CSC242-GreenvilleIdol-201804Fall/CSC242-GreenvilleIdol-201804Fall
 * 
 **************************************/

namespace GreenvilleIdol
{
    class GreenvilleTest
    {
        static void Main( string[] args )
        {
            // GUI implementation
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new UxGreenvilleRevenueGUI());

            // console implementation
            //char[] codes;
            //string[] names;
            //char code = 'a';

            //GreenvilleMotto2 gm2 = new GreenvilleMotto2();
            //WriteLine(gm2.Motto2());
            //WriteLine();

            //GreenvilleRevenue gr = new GreenvilleRevenue();

            //// ask for number of contestant this year, validate (0-30 only, no other charactres)
            //Write("Enter the number of contestant for this year: ");
            //gr.NumContestantsThisYear = gr.ValidateNumbers(gr.CheckInputForInteger(ReadLine()));
            //WriteLine();

            //// ask for number of contestant last year, validate (0-30 only, no other charactres)
            //Write("Enter the number of contestants for last year: ");
            //gr.NumContestantsLastYear = gr.ValidateNumbers(gr.CheckInputForInteger(ReadLine()));

            //WriteLine("The revenue for this year is: {0}", gr.Revenue(gr.NumContestantsThisYear).ToString("c"));
            //WriteLine(gr.CompareContestantNumbers(gr.NumContestantsThisYear, gr.NumContestantsLastYear));
            //WriteLine();

            //names = new string[gr.NumContestantsThisYear];
            //codes = new char[gr.NumContestantsThisYear];

            //gr.InputArray(names, codes);
            //gr.DisplayArray(names, codes);

            //WriteLine("There are {0} Singing talent contestants.", gr.DisplayCount(codes, 'S'));
            //WriteLine("There are {0} Dancing talent contestants.", gr.DisplayCount(codes, 'D'));
            //WriteLine("There are {0} Musical talent contestants.", gr.DisplayCount(codes, 'M'));
            //WriteLine("There are {0} Other talent contestants.", gr.DisplayCount(codes, 'O'));

            //gr.DisplayNames(code, codes, names);

            //GreenvilleMotto gm = new GreenvilleMotto();
            //WriteLine();
            //WriteLine(gm.Motto());

            //ReadLine();
        }
    }
}
