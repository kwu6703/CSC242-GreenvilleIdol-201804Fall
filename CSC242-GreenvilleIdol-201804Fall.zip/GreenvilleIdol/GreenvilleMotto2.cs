﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**************************************
 * Names:               Ian Stebbins 
 * Date Started:        11/29/2018
 * Date Due:            12/14/2018
 * Description:         Greenville Idol - Chapter 2
 * 
 * Resources:  Microsoft Azure DevOps
 *             https://dev.azure.com/CSC242-GreenvilleIdol-201804Fall/CSC242-GreenvilleIdol-201804Fall
 * 
 **************************************/


namespace GreenvilleIdol
{
    class GreenvilleMotto2
    {
        public string Motto2()
        {
            return String.Format("*********************************\n" +
                                 "* The stars shine in Greenville *\n" +
                                 "*********************************");
        }
    }
}
