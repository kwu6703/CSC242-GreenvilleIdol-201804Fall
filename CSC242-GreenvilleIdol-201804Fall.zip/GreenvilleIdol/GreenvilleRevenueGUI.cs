﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**************************************
 * Names:               Kaixin Wu 
 * Date Started:        11/29/2018
 * Date Due:            12/14/2018
 * Description:         Greenville Idol - Chapter 1
 * 
 * Resources:  Microsoft Azure DevOps
 *             https://dev.azure.com/CSC242-GreenvilleIdol-201804Fall/CSC242-GreenvilleIdol-201804Fall
 * 
 **************************************/


namespace GreenvilleIdol
{
    public partial class UxGreenvilleRevenueGUI : Form
    {
        GreenvilleRevenue gr = new GreenvilleRevenue();
        GreenvilleMotto gm = new GreenvilleMotto();

        public UxGreenvilleRevenueGUI()
        {
            InitializeComponent();
            GreenvilleMotto2 gm2 = new GreenvilleMotto2();
            UxGreenvilleMotto2Label.Text = gm2.Motto2();
        }

        private void UxNumOfContestantsThisYearNumericUpDow_Leave( object sender, EventArgs e )
        {
            gr.NumContestantsThisYear = gr.ValidateNumbers(gr.CheckInputForInteger(UxNumOfContestantsThisYearNumericUpDown.Text));
            UxNumOfContestsThisYearOutputTextBox.Text = gr.NumContestantsThisYear.ToString();
        }

        private void UxNumOfContestantsLastYearNumericUpDown_Leave( object sender, EventArgs e )
        {
            gr.NumContestantsLastYear = gr.ValidateNumbers(gr.CheckInputForInteger(UxNumOfContestantsLastYearNumericUpDown.Text));
            UxNumOfContestantsLastYearOutputTextBox.Text = gr.NumContestantsLastYear.ToString();

            // Compare the number of contestants for each year
            UxCompareLabel.Text = (gr.CompareContestantNumbers(gr.NumContestantsThisYear, gr.NumContestantsLastYear)).ToString() + Environment.NewLine +
                gm.Motto();

            // Revenue projection
            UxRevenueTextBox.Text = String.Format(gr.Revenue(gr.NumContestantsThisYear).ToString("C2"));
        }
    }
}
