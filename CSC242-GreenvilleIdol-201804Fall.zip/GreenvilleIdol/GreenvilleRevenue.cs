﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

/**************************************
 * Contributors:        Jonathan Cooper, 
 *                      Minh Nhat Dang, 
 *                      Colin Helton, 
 *                      Ian Stebbins, 
 *                      Kaixin Wu
 * Date Started:        11/29/2018
 * Date Due:            12/14/2018
 * Description:         Greenville Idol - Chapters 4, 5, 6, 7, 8
 * 
 * Resources:  Microsoft Azure DevOps
 *             https://dev.azure.com/CSC242-GreenvilleIdol-201804Fall/CSC242-GreenvilleIdol-201804Fall
 * 
 **************************************/

namespace GreenvilleIdol
{
    class GreenvilleRevenue
    {
        private int numContestantsThisYear; // this year
        private int numContestantsLastYear; // last year


        // default constructor
        public GreenvilleRevenue()
        {
            // implentation left empty on purpose
        }

        public int NumContestantsThisYear
        {
            get { return numContestantsThisYear; }
            set { numContestantsThisYear = value; }
        }

        public int NumContestantsLastYear
        {
            get { return numContestantsLastYear; }
            set { numContestantsLastYear = value; }
        }

        public int Revenue( int numberOfContestant1 )
        {
            return NumContestantsThisYear * 25;
        }

        public int CheckInputForInteger( string aNum )
        {
            int num = -99; // just a random, bad number
            bool isInputAnInt;
            isInputAnInt = int.TryParse(aNum, out num);

            while (isInputAnInt == false)
            {
                DisplayError(); // to be added
                aNum = ReadLine();
                isInputAnInt = int.TryParse(aNum, out num);
            }
            return num;
        }

        public void DisplayError()
        {
            WriteLine(" ** Input data was not an integer.");
            Write(" ** Please enter an integer (0-30): ");
        }

        public string CompareContestantNumbers( int numberOfContestant1, int numberOfContestant2 )
        {
            if (NumContestantsThisYear > NumContestantsLastYear * 2)
            {
                return string.Format("The competition is more than twice as big this year!");
            }
            else
            {
                if (NumContestantsThisYear > NumContestantsLastYear) // this part was not necessary && NumContestantsThisYear < NumContestantsLastYear * 2)
                {
                    return string.Format("The competition is bigger then ever!");
                }
                else
                {
                    // NumContestantsThisYear <= NumContestantsLastYear
                    return string.Format("A tighter race this year! Come out and cast your vote!");
                }
            }
        } // end method CheckContestants

        public int ValidateNumbers( int num )
        {
            while ((num < 0) || (num > 30))
            {
                WriteLine("Enter the contestant (0 through 30): ");
                num = Convert.ToInt32(ReadLine());
            }
            return num;
        } // end method ValidateNumber

        public void InputArray( string[] names, char[] codes )
        {
            for (int i = 0; i < names.Length; i++)
            {
                WriteLine("Enter the name for contestant {0}: ", i + 1);
                names[i] = ReadLine();

                do
                {
                    WriteLine("Enter the talent code for contestant {0} :", i + 1);
                    codes[i] = Convert.ToChar(ReadLine());
                    codes[i] = char.ToUpper(codes[i]);
                } while (codes[i] != 'S' && codes[i] != 'D' && codes[i] != 'M' && codes[i] != 'O');
            }
        }//end InputArray

        public void DisplayArray( string[] names, char[] codes )
        {
            foreach (string name in names)
            {
                Write("{0,10}", name);
            }
            WriteLine();
            foreach (char code in codes)
            {
                Write("{0,10}", code);
            }
            WriteLine();
        }// end DisplayArray

        public int DisplayCount( char[] codes, char inputChar )
        {
            int count = 0;

            foreach (char code in codes)
            {
                if (code == inputChar)
                {
                    count++;
                }
            }
            return count;
        }// end DisplayCount

        public void DisplayNames( char code, char[] codes, string[] names )
        {
            do
            {
                WriteLine("What talent would you like to see?(to exit, press x)");
                code = Convert.ToChar(ReadLine());
                code = char.ToUpper(code);
                for (int i = 0; i < codes.Length; ++i)
                {
                    if (codes[i] == code)
                    {
                        WriteLine("{0,10}", names[i]);
                    }
                }
            } while (code != 'X');
        }//end DisplayNames

    } // end class GreenvilleRevenue.cs
} // end namespace
