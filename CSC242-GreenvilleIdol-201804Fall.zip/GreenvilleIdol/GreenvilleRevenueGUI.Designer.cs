﻿namespace GreenvilleIdol
{
    partial class UxGreenvilleRevenueGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UxNumOfContestsLastYearOutputLabel = new System.Windows.Forms.Label();
            this.UxNumOfContestsThisYearOutputLabel = new System.Windows.Forms.Label();
            this.UxRevenueLabel = new System.Windows.Forms.Label();
            this.UxNumOfContestantsLastYearOutputTextBox = new System.Windows.Forms.TextBox();
            this.UxRevenueTextBox = new System.Windows.Forms.TextBox();
            this.UxGreenvilleMotto2Label = new System.Windows.Forms.Label();
            this.UxNumOfContestantsThisYearLabel = new System.Windows.Forms.Label();
            this.UxNumOfContestsThisYearOutputTextBox = new System.Windows.Forms.TextBox();
            this.UxNumOfContestantsLastYearLabel = new System.Windows.Forms.Label();
            this.UxCompareLabel = new System.Windows.Forms.Label();
            this.UxNumOfContestantsThisYearNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.UxNumOfContestantsLastYearNumericUpDown = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.UxNumOfContestantsThisYearNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UxNumOfContestantsLastYearNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // UxNumOfContestsLastYearOutputLabel
            // 
            this.UxNumOfContestsLastYearOutputLabel.AutoSize = true;
            this.UxNumOfContestsLastYearOutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxNumOfContestsLastYearOutputLabel.Location = new System.Drawing.Point(12, 225);
            this.UxNumOfContestsLastYearOutputLabel.Name = "UxNumOfContestsLastYearOutputLabel";
            this.UxNumOfContestsLastYearOutputLabel.Size = new System.Drawing.Size(246, 20);
            this.UxNumOfContestsLastYearOutputLabel.TabIndex = 0;
            this.UxNumOfContestsLastYearOutputLabel.Text = "Last year we have contestants of ";
            // 
            // UxNumOfContestsThisYearOutputLabel
            // 
            this.UxNumOfContestsThisYearOutputLabel.AutoSize = true;
            this.UxNumOfContestsThisYearOutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxNumOfContestsThisYearOutputLabel.Location = new System.Drawing.Point(12, 187);
            this.UxNumOfContestsThisYearOutputLabel.Name = "UxNumOfContestsThisYearOutputLabel";
            this.UxNumOfContestsThisYearOutputLabel.Size = new System.Drawing.Size(265, 20);
            this.UxNumOfContestsThisYearOutputLabel.TabIndex = 1;
            this.UxNumOfContestsThisYearOutputLabel.Text = "Number of contestants for this year: ";
            // 
            // UxRevenueLabel
            // 
            this.UxRevenueLabel.AutoSize = true;
            this.UxRevenueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxRevenueLabel.Location = new System.Drawing.Point(12, 263);
            this.UxRevenueLabel.Name = "UxRevenueLabel";
            this.UxRevenueLabel.Size = new System.Drawing.Size(193, 20);
            this.UxRevenueLabel.TabIndex = 2;
            this.UxRevenueLabel.Text = "We are expecting to make";
            // 
            // UxNumOfContestantsLastYearOutputTextBox
            // 
            this.UxNumOfContestantsLastYearOutputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxNumOfContestantsLastYearOutputTextBox.Location = new System.Drawing.Point(318, 222);
            this.UxNumOfContestantsLastYearOutputTextBox.Name = "UxNumOfContestantsLastYearOutputTextBox";
            this.UxNumOfContestantsLastYearOutputTextBox.ReadOnly = true;
            this.UxNumOfContestantsLastYearOutputTextBox.Size = new System.Drawing.Size(100, 26);
            this.UxNumOfContestantsLastYearOutputTextBox.TabIndex = 5;
            this.UxNumOfContestantsLastYearOutputTextBox.TabStop = false;
            this.UxNumOfContestantsLastYearOutputTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // UxRevenueTextBox
            // 
            this.UxRevenueTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxRevenueTextBox.Location = new System.Drawing.Point(318, 260);
            this.UxRevenueTextBox.Name = "UxRevenueTextBox";
            this.UxRevenueTextBox.ReadOnly = true;
            this.UxRevenueTextBox.Size = new System.Drawing.Size(100, 26);
            this.UxRevenueTextBox.TabIndex = 7;
            this.UxRevenueTextBox.TabStop = false;
            this.UxRevenueTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // UxGreenvilleMotto2Label
            // 
            this.UxGreenvilleMotto2Label.AutoSize = true;
            this.UxGreenvilleMotto2Label.BackColor = System.Drawing.Color.DimGray;
            this.UxGreenvilleMotto2Label.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxGreenvilleMotto2Label.ForeColor = System.Drawing.Color.Gold;
            this.UxGreenvilleMotto2Label.Location = new System.Drawing.Point(12, 9);
            this.UxGreenvilleMotto2Label.Name = "UxGreenvilleMotto2Label";
            this.UxGreenvilleMotto2Label.Size = new System.Drawing.Size(346, 24);
            this.UxGreenvilleMotto2Label.TabIndex = 9;
            this.UxGreenvilleMotto2Label.Text = "GreenvilleMotto2 placeholder";
            // 
            // UxNumOfContestantsThisYearLabel
            // 
            this.UxNumOfContestantsThisYearLabel.AutoSize = true;
            this.UxNumOfContestantsThisYearLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxNumOfContestantsThisYearLabel.Location = new System.Drawing.Point(12, 90);
            this.UxNumOfContestantsThisYearLabel.Name = "UxNumOfContestantsThisYearLabel";
            this.UxNumOfContestantsThisYearLabel.Size = new System.Drawing.Size(265, 20);
            this.UxNumOfContestantsThisYearLabel.TabIndex = 10;
            this.UxNumOfContestantsThisYearLabel.Text = "How many contestants for this year: ";
            // 
            // UxNumOfContestsThisYearOutputTextBox
            // 
            this.UxNumOfContestsThisYearOutputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxNumOfContestsThisYearOutputTextBox.Location = new System.Drawing.Point(318, 184);
            this.UxNumOfContestsThisYearOutputTextBox.Name = "UxNumOfContestsThisYearOutputTextBox";
            this.UxNumOfContestsThisYearOutputTextBox.ReadOnly = true;
            this.UxNumOfContestsThisYearOutputTextBox.Size = new System.Drawing.Size(100, 26);
            this.UxNumOfContestsThisYearOutputTextBox.TabIndex = 6;
            this.UxNumOfContestsThisYearOutputTextBox.TabStop = false;
            this.UxNumOfContestsThisYearOutputTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // UxNumOfContestantsLastYearLabel
            // 
            this.UxNumOfContestantsLastYearLabel.AutoSize = true;
            this.UxNumOfContestantsLastYearLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxNumOfContestantsLastYearLabel.Location = new System.Drawing.Point(12, 122);
            this.UxNumOfContestantsLastYearLabel.Name = "UxNumOfContestantsLastYearLabel";
            this.UxNumOfContestantsLastYearLabel.Size = new System.Drawing.Size(265, 20);
            this.UxNumOfContestantsLastYearLabel.TabIndex = 12;
            this.UxNumOfContestantsLastYearLabel.Text = "How many contestants for last year: ";
            // 
            // UxCompareLabel
            // 
            this.UxCompareLabel.AutoSize = true;
            this.UxCompareLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxCompareLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.UxCompareLabel.Location = new System.Drawing.Point(16, 301);
            this.UxCompareLabel.Name = "UxCompareLabel";
            this.UxCompareLabel.Size = new System.Drawing.Size(0, 20);
            this.UxCompareLabel.TabIndex = 14;
            // 
            // UxNumOfContestantsThisYearNumericUpDown
            // 
            this.UxNumOfContestantsThisYearNumericUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxNumOfContestantsThisYearNumericUpDown.Location = new System.Drawing.Point(318, 83);
            this.UxNumOfContestantsThisYearNumericUpDown.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.UxNumOfContestantsThisYearNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.UxNumOfContestantsThisYearNumericUpDown.Name = "UxNumOfContestantsThisYearNumericUpDown";
            this.UxNumOfContestantsThisYearNumericUpDown.Size = new System.Drawing.Size(100, 26);
            this.UxNumOfContestantsThisYearNumericUpDown.TabIndex = 0;
            this.UxNumOfContestantsThisYearNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.UxNumOfContestantsThisYearNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.UxNumOfContestantsThisYearNumericUpDown.Leave += new System.EventHandler(this.UxNumOfContestantsThisYearNumericUpDow_Leave);
            // 
            // UxNumOfContestantsLastYearNumericUpDown
            // 
            this.UxNumOfContestantsLastYearNumericUpDown.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UxNumOfContestantsLastYearNumericUpDown.Location = new System.Drawing.Point(318, 122);
            this.UxNumOfContestantsLastYearNumericUpDown.Maximum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.UxNumOfContestantsLastYearNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.UxNumOfContestantsLastYearNumericUpDown.Name = "UxNumOfContestantsLastYearNumericUpDown";
            this.UxNumOfContestantsLastYearNumericUpDown.Size = new System.Drawing.Size(100, 26);
            this.UxNumOfContestantsLastYearNumericUpDown.TabIndex = 1;
            this.UxNumOfContestantsLastYearNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.UxNumOfContestantsLastYearNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.UxNumOfContestantsLastYearNumericUpDown.Leave += new System.EventHandler(this.UxNumOfContestantsLastYearNumericUpDown_Leave);
            // 
            // UxGreenvilleRevenueGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(430, 363);
            this.Controls.Add(this.UxNumOfContestantsLastYearNumericUpDown);
            this.Controls.Add(this.UxNumOfContestantsThisYearNumericUpDown);
            this.Controls.Add(this.UxCompareLabel);
            this.Controls.Add(this.UxNumOfContestantsLastYearLabel);
            this.Controls.Add(this.UxNumOfContestantsThisYearLabel);
            this.Controls.Add(this.UxGreenvilleMotto2Label);
            this.Controls.Add(this.UxRevenueTextBox);
            this.Controls.Add(this.UxNumOfContestsThisYearOutputTextBox);
            this.Controls.Add(this.UxNumOfContestantsLastYearOutputTextBox);
            this.Controls.Add(this.UxRevenueLabel);
            this.Controls.Add(this.UxNumOfContestsThisYearOutputLabel);
            this.Controls.Add(this.UxNumOfContestsLastYearOutputLabel);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "UxGreenvilleRevenueGUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Greenville Idol";
            ((System.ComponentModel.ISupportInitialize)(this.UxNumOfContestantsThisYearNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UxNumOfContestantsLastYearNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label UxNumOfContestsLastYearOutputLabel;
        private System.Windows.Forms.Label UxNumOfContestsThisYearOutputLabel;
        private System.Windows.Forms.Label UxRevenueLabel;
        private System.Windows.Forms.TextBox UxNumOfContestantsLastYearOutputTextBox;
        private System.Windows.Forms.TextBox UxRevenueTextBox;
        private System.Windows.Forms.Label UxGreenvilleMotto2Label;
        private System.Windows.Forms.Label UxNumOfContestantsThisYearLabel;
        private System.Windows.Forms.TextBox UxNumOfContestsThisYearOutputTextBox;
        private System.Windows.Forms.Label UxNumOfContestantsLastYearLabel;
        private System.Windows.Forms.Label UxCompareLabel;
        private System.Windows.Forms.NumericUpDown UxNumOfContestantsThisYearNumericUpDown;
        private System.Windows.Forms.NumericUpDown UxNumOfContestantsLastYearNumericUpDown;
    }
}